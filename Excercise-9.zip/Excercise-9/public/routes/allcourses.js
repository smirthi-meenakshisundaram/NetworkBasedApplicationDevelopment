var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var router = express.Router();
var session = require('express-session');
var courselist =require('../model/Coursemodel');
var mongoose = require('mongoose');
app.use(session({ secret: 'my secret' }));

mongoose.connect('mongodb://localhost/Courses', {useNewUrlParser: true});
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  
});

router.get('/',function (req, res) {

  courselist.find()
  .then(function(results){
    res.render('allcourses', {courses:results});
    res.end();
  })

});

var urlencodedParser = bodyParser.urlencoded({ extended: false });



router.post('/searchcourse', urlencodedParser,function(req, res) {
	var post_id = req.body.search;
	post_id = parseInt(post_id)
	courselist.find({ courseID: post_id }, function(err, searchresult) {
		console.log(searchresult);
		res.render('allcourses',{courses:searchresult});
		res.end();

	});

});

module.exports= router;

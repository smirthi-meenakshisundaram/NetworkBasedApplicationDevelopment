var express = require('express');
var router = express.Router();
var courseDetails= require('./coursedetails.js')
var mongoose = require('mongoose');
var Course = require('../model/Coursemodel');


mongoose.connect('mongodb://localhost/Courses', { useNewUrlParser: true });
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
    // we're connected!`enter code here

    var c1 = new Course({
        courseID: 1211,
        title: 'C Programming',
        term: 'Fall2019',
        instructor: 'Seema',
        starttime: '10AM',
        endtime: '11AM',
        emailid: 'seema5@uncc.edu'
    });
    var c2 = new Course({
        courseID: 1211,
        title: 'Java Programming',
        term: 'Fall2020',
        instructor: 'Rob',
        starttime: '11AM',
        endtime: '12PM',
        emailid: 'rob2@uncc.edu'
    });
    var c3 = new Course({
        courseID: 6162,
        title: 'Python Programming',
        term: 'Spring2019',
        instructor: 'Pooja',
        starttime: '9AM',
        endtime: '10AM',
        emailid: 'pooja4@uncc.edu'
    });
    var c4 = new Course({
        courseID: 6162,
        title: 'My Sql',
        term: 'Spring2020',
        instructor: 'Bob',
        starttime: '8AM',
        endtime: '9AM',
        emailid: 'bob5@uncc.edu'
    });

    c1.save(function(err, c1) {
        if (err) return console.error(err);
        console.log("course 1 saved");
    });
    c2.save(function(err, c2) {
        if (err) return console.error(err);
        console.log("course 2 saved");
    });
    c3.save(function(err, c3) {
        if (err) return console.error(err);
        console.log("course 3 saved");
    });
    c4.save(function(err, c4) {
        if (err) return console.error(err);
        console.log("course 4 saved");
    });

});






router.get('/', function (req, res) {
  res.render('index',{x:courseDetails.x()});
});

module.exports = router;

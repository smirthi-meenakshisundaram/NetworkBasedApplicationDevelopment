var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var router = express.Router();
var session = require('express-session');
var urlencodedParser = bodyParser.urlencoded({ extended: false });

var courselist =require('../model/Coursemodel');
var mongoose = require('mongoose');

const { check, validationResult } = require('express-validator');

mongoose.connect('mongodb://localhost/Courses', {useNewUrlParser: true});
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));



app.use(session({ secret: 'my secret' }));

var theCourse;
var x = 0;
// callback function is used. Most of them use the next function for the middleware, but the naming does not matter
// the main thing that matters is that the callBack function is sent as the third argument to the logger.
var loggerFun = function(req,res,callback){
    x+=1;
    console.log("The form was submitted these many times :" + x);
    callback();

}

router.post('/', urlencodedParser,loggerFun,[
  check('title').isLength({ min: 2 }),
  check('id').isNumeric(),
  check('term').isAlphanumeric(),
  check('instructors').isLength({min:2}),
  check('starttime').isAlphanumeric(),
  check('endtime').isAlphanumeric(),
  check('emailid').isEmail(),

],function(req, res) {

    const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(422).json({ errors: errors.array() })
      }

    var courseModel = require('../model/course.js');
    var post_id = req.body.id;
    var post_Title = req.body.title;
    var post_Term = req.body.term;
    var post_Instructor = req.body.instructors;
    var post_start = req.body.starttime;
    var post_end = req.body.endtime;
    var post_email = req.body.emailid;

    post_id = parseInt(post_id);
    courseModel = courseModel.coursedetails(post_id,
        post_Title,
        post_Term,
        post_Instructor);
    req.session.theCourse = courseModel;



    courselist.find({ courseID: post_id ,term: post_Term,instructor: post_Instructor}, function(err, searchresult) {
        if(searchresult.length > 0){
            var myquery = { courseID: post_id,term:post_Term,instructor:post_Instructor};
            var newvalues = { courseID: post_id,title: post_Title,term:post_Term,instructor:post_Instructor,
                starttime:post_Instructor,endtime:post_Instructor,emailid:post_email};
            courselist.updateOne(myquery, newvalues, function(err, res) {
                if (err) console.log(err);
                console.log("Document has updated");
              });
            res.redirect('/');
        }
        else{
            var newcourse = new courselist({
                courseID: post_id,
                title: post_Title,
                term: post_Term,
                instructor: post_Instructor,
                starttime: post_start,
                endtime: post_end,
                emailid: post_email
            });
            newcourse.save(function(err, newcourse) {
                if (err) return console.error(err);
                console.log("new course added");
            });
            res.redirect('/allcourses');

        }


    });
    // if (req.session.theCourse.CourseId == '') {
    //     res.redirect('/index',{x:x});
    // }
    // else {
    //     res.redirect('/coursedetails');
    // }

});

router.get('/', function(req, res) {
    if (req.session.theCourse) {
        res.render('details', { course: req.session.theCourse });
        res.end();
    } else {

        res.render('index',{x:x});
        res.send();
    }
});


module.exports = router;
module.exports.x = function(value) {
    visit_counter = x;
    return visit_counter;
};

var course = function(id, title, term, instructor,starttime,endtime,emailid){
  var courseModel={
    CourseId: id,
    Title: title,
    Term: term,
    Instructor: instructor,
    Starttime: starttime,
	Endtime: endtime,
	Emailid: emailid };
    return courseModel;
}

module.exports.coursedetails=course;

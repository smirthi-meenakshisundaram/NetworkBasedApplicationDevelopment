var express = require('express');
var app = express();
var path = require('path');
var session = require('express-session');
var mongoose = require('mongoose');

app.set('view engine', 'ejs');
app.set('views', '../views');
app.use('/assets/stylesheets', express.static(path.join(__dirname,'/../assets/stylesheets')));
app.use('/assets/images', express.static(path.join(__dirname,'/../assets/images')));

var course = require('../routes/coursedetails.js');
var allcourses = require('../routes/allcourses.js');

var index = require('../routes/index.js');

app.use(session({secret: 'my course secret'}));
app.use('/coursedetails',course);
app.use('/allcourses',allcourses);
app.use('/*',index);


app.listen(8084,function(){
    console.log('app started');
    console.log('listening on port 8084');
});

var express = require('express');
var app = express();
var path = require('path')
var utility = require('../util/connectionDB');

var index = require('../routes/index');
app.use('/', index);
app.use(express.static("../assets"));
app.set("views", "../views");
app.set('view engine', 'ejs');
 


app.listen(9090, function() {
    console.log('app started')
    console.log('listening on port 9090')
});

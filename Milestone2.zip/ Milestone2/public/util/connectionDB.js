

var connectionModel = require('../models/connection');

//Here we hardcode all the data and retrieve it using the getConnection and getConnections

var Sanju=
 {
    connectionID:'AWA01',
    connectionName:'Best Actor',
    connectiontopic:"Awards",
    details:"Sanju is a 2018 Indian semi biographical film directed by Rajkumar Hirani and written by Hirani and Abhijat Joshi. ... Ranbir Kapoor stars as Dutt, along with an ensemble cast which features Paresh Rawal, Vicky Kaushal, Manisha Koirala, Dia Mirza, Sonam Kapoor, Anushka Sharma and Jim Sarbh.",
    releasedateTime:"June 29th,2018 3:00pm",
    location:"Film was shot in Newyork",
    imageurl:'images/sanjupic.jpg'
   };

   var Raazi=
    {
       connectionID:'AWA02',
       connectionName:'Best Director',
       connectiontopic:"Awards",
       details:"The Raazi Movie was Directed by Meghana Gulzar.revolves around the life of an Indian spy Sehmat, played by Alia Bhatt who is married to a Pakistani officer. The critically acclaimed spy thriller is reportedly based on a true story. The film is mainly an adaptation of Harinder Sikka's 2008 novel titled 'Calling Sehmat",
       releasedateTime:"May 10th,2018 5:00pm",
       location:"Film was shot in Pakisthan",
       imageurl:'images/Raazi.jpg'
      };

      var Andhadhun=
       {
          connectionID:'AWA03',
          connectionName:'Best Film',
          connectiontopic:"Awards",
          details:"The film stars Tabu, Ayushmann Khurrana, and Radhika Apte, and tells the story of a blind piano player who unwittingly becomes embroiled in the murder of a former film actor.  ",
          releasedateTime:"October 1st,2018 9:00pm",
          location:"Film was shot in India",
          imageurl:'images/andhadhun.jpeg'
         };

         var Padmaavat=
          {
             connectionID:'NOM01',
             connectionName:'Best Actor',
             connectiontopic:"Nominations",
             details:"Padmaavat is a 2018 Indian Hindi-language epic period drama film directed by Sanjay Leela Bhansali. Loosely based on the epic poem Padmavat by Malik Muhammad Jayasi, it stars Deepika Padukone as Rani Padmavati, a Rajput queen known for her beauty, wife of Maharawal Ratan Singh, played by Shahid Kapoor.",
             releasedateTime:"January 25th,2018 8:00pm",
             location:"Film was shot in Sanjay Leela Bhansalis Indianised epic set",
             imageurl:'images/padmaavat.jpg'
            };


            var Stree=
             {
                connectionID:'NOM02',
                connectionName:'Best Director',
                connectiontopic:"Nominations",
                details:" Stree is a 2018 Indian comedy horror film directed by Amar Kaushik, written by Raj Nidimoru and Krishna D.K. and produced by Dinesh Vijan and Raj Nidimoru and Krishna D.K. ... Stree stars Rajkummar Rao and Shraddha Kapoor.",
                releasedateTime:"August 30th,2018 11:00pm",
                location:"Film was shot in India",
                imageurl:'images/stree.jpg'
               };

               var Hichki=
                {
                   connectionID:'NOM03',
                   connectionName:'Best Film',
                   connectiontopic:"Nominations",
                   details:" Hichki presents a positive and inspiring story about a woman who turns her biggest weakness into her biggest strength. Hichki is a story about a woman who turns her most daunting weakness into her biggest strength. Naina Mathur (Rani Mukerji) is an aspiring teacher who suffers from Tourette Syndrome",
                   releasedateTime:"March 23rd,2018 10:00pm",
                   location:"Film was shot in India and part of it in United States",
                   imageurl:'images/hichki.jpg'
                  };

  var allConnections=
    [
         Sanju,
         Raazi,
         Andhadhun,
         Padmaavat,
         Stree,
         Hichki
    ];



    var getConnections=function()
    {
      var myList=[];

       for(i=0;i<=allConnections.length-1;i++){

          connection = new connectionModel();
          connection.connectionID = allConnections[i].connectionID,
          connection.connectionName = allConnections[i].connectionName,
          connection.connectiontopic = allConnections[i].connectiontopic,
          connection.details = allConnections[i].details,
          connection.releasedateTime = allConnections[i].releasedateTime,
          connection.location = allConnections[i].location,
          connection.imageurl = allConnections[i].imageurl;
          myList.push(connection);


       }

       return myList
    };


    //get individual connection based on the connection ID
    var getConnection=function(connectionID)
    {

      for(i=0;i<allConnections.length;i++){
        var abc = connectionID.split("");
          connection = new connectionModel();
        if(allConnections[i].connectionID==connectionID){
          connection.connectionID = allConnections[i].connectionID,
          connection.connectionName = allConnections[i].connectionName,
          connection.connectiontopic = allConnections[i].connectiontopic,
          connection.details = allConnections[i].details,
          connection.releasedateTime = allConnections[i].releasedateTime,
          connection.location = allConnections[i].location,
          connection.imageurl = allConnections[i].imageurl;
          return connection;
        }
        else if(abc.length == 0){
         conn = new connectionModel();
         return conn;
        }
      }
    };

//to get the details of a particular connetion ID

module.exports.getConnections=getConnections;
module.exports.getConnection=getConnection;

var express = require('express');
var router = express.Router();
var utility = require('../util/connectionDB');

//renders all the pages 

router.get('/', function(req, res) {
    res.render('index')
})

router.get('/about', function(req, res) {
    res.render('about')
})

router.get('/contact', function(req, res) {
    res.render('contact')
})


// router.get('/connections', function(req, res) {
//     res.render('pages/connections')
// })

router.get('/savedConnections', function(req, res) {
    res.render('savedconnections')
})
router.get('/newConnection', function(req, res) {
    res.render('newConnection')
});

router.get('/connections',function(req,res){
 var filmCat = [];
 var film = utility.getConnections();
 for(var i=0;i<film.length;i++){
   filmCat.push(film[i].connectiontopic)
 }
 var Category = filmCat.filter((cat,ind,item)=>item.indexOf(cat) ===ind);
 res.render('connections',{querystring:film,unique:Category});
});


router.get('/connection', function(req, res) {
	var ID = req.query.ID

	var detail = utility.getConnection(ID);

	var response = [];
	response.push(detail);

  console.log(response.length);
    res.render('connection',{querystring:response})
})

module.exports = router;

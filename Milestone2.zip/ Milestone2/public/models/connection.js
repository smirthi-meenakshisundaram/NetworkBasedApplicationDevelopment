// creating a class connection and using get and set to get the values

class Connection {
    _connectionID = {
        type: String,
        value: null,
        required: true,
        unique: true
    };
    _connectionName = {
        type: String,
        value: null,
        required: true
    };
    _connectiontopic = {
        type: String,
        value: null,
        required: true
    };
    _details = {
        type: String,
        value: null
    };

  _releasedateTime = {
        type: String,
        value: null,
        required: true
    };
    _location = {
          type: String,
          value: null,
          required: true
      };
    _imageurl = {
        type: String,
        value: null
    };
    get connectionID () {
        return this._connectionID;
    }
    set connectionID(value) {
        this._connectionID = value;
    }
    get connectionName () {
        return this._connectionName;
    }
    set connectionName(value) {
        this._connectionName = value;
    }
    get connectiontopic () {
        return this._connectiontopic;
    }
    set connectiontopic(value) {
        this._connectiontopic = value;
    }
    get details () {
        return this._details;
    }
    set details(value) {
        this._details = value;
    }
    get releasedateTime () {
        return this._releasedateTime;
    }
    set releasedateTime(value) {
        this._releasedateTime = value;
    }
    get imageUrl () {
        return this._imageUrl;
    }
    set imageUrl(value) {
        this._imageUrl = value;
    }
}

module.exports = Connection;

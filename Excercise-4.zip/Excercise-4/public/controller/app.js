
var express = require('express');
var app = express();
var path = require('path');
var session = require('express-session')

app.set('view engine', 'ejs');
app.set('views', '../views');
app.use('/assets/stylesheets',express.static(path.join(__dirname,'/../assets/stylesheets')));
app.use('/assets/images',express.static(path.join(__dirname,'/../assets/images')));



var course = require('../routes/courseDetails.js');

var index = require('../routes/index.js');

app.use(session({secret:'About Course'}));
app.use('/courseDetails',course);
app.use('/*',index);


app.listen(8084,function(){
    console.log('app started')
    console.log('listening on port 8084')
});

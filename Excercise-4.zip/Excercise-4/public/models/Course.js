var course = function(id,title,term,ins){
  var courseModel={courseID:id,
                    title:title,
                    term:term,
                    instructor:ins};
  return courseModel;
};

module.exports.course=course;

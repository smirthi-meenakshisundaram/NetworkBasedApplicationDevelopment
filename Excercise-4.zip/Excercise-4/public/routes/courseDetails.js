var express = require('express');
var app = express();
var bodyParser=require('body-parser');
var router = express.Router();
var session = require('express-session');
var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.use(session({secret:'About Course'}));

var theCourse;

 router.post('/',urlencodedParser,function(req,res){

    var courseModel = require('./../models/Course');
    var post_id = req.body.Id;
  var post_Title = req.body.Title;
  var post_Term = req.body.Term;
  var post_Instructor = req.body.Instructor;

     courseModel = courseModel.course(req.body.courseID,
                                      req.body.title,
                                      req.body.term,
                                      req.body.instructor);
req.session.theCourse=courseModel;

if(req.session.theCourse.courseID==''){
  res.redirect('/index');

} else{

    console.log(req.session.theCourse.courseID);
    console.log(Object.values(req.session.theCourse).length);
    res.redirect('/courseDetails');
  }
});
  router.get('/', function (req, res) {

 if(req.session.theCourse){
res.render('details', {course:req.session.theCourse});
               res.end();
         }
         else{
          console.log("in no info");
          res.render('index');
          res.end();
         }

     });



module.exports = router;

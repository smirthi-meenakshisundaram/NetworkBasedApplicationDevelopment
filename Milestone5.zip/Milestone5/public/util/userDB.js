var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
mongoose.Promise = global.Promise;
var user = require("../models/User");
var UserConnection = require("../models/userConnection");






module.exports.getUsers = function () {
    var usr = user.find();
    return usr;
}

module.exports.getUserConnections = function () {
    var userconnections = UserConnection.find();
    return userconnections;
}



module.exports.getUser = function (id) {
  var usercon = user.find({UserID: id});
  return usercon;
}

module.exports.getLoginDetails = function (email) {
    var loginDetails = user.find({ username: email});
    console.log('loginDetails');
    console.log(loginDetails);
    return loginDetails
}

module.exports.getUserConnectionsWithCode = function (ucode) {
    var nameWcode = UserConnection.find({ UserID: ucode })
    return nameWcode;
}

 /*

module.exports.hashPassword = function () {
    var hashPass = []
    for (var i = 0; i < userCredentials.length; i++) {
        let hash = bcrypt.hashSync(userCredentials[i].password, 10)
        var obj = { ucode: userCredentials[i].ucode, username: userCredentials[i].username, password: hash }
        hashPass.push(obj)
    }
    user.countDocuments().exec(function (err, docs) {
        if (docs == 0) {
            user.insertMany(hashPass, function (err) {
                if (err) {
                    console.log("Insert only unique values")
                }
            });
        }
    })
    return hashPass
}
*/

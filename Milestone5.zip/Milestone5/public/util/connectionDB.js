var Award = require('../models/connection')
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
mongoose.Promise = global.Promise;


module.exports.getConnections = function () {
   var cons = Award.find();

   return cons;
}

module.exports.getConnection = function (connectionID) {
   var cId = Award.find({ "connectionID": connectionID });
   return cId;
}
module.exports.getCategory = function () {
    var cats = Award.distinct("connectiontopic");
    return cats;
}
module.exports.getConnectionByName = function (name) {
    var con1 = Award.find({ connectionName: name } )
    //console.log('con1:',con1);
    return con1;
}

module.exports.getSize = function () {
    var size = Award.count();
    return size;
}

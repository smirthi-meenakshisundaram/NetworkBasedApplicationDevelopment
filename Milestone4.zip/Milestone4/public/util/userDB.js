var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
mongoose.Promise = global.Promise;
var user = require("../models/User");
var UserConnection = require("../models/userConnection");





module.exports.getUsers = function () {
    var usr = user.find();
    return usr;
}

module.exports.getUserConnections = function () {
    var userconnections = UserConnection.find();
    return userconnections;
}



module.exports.getUser = function (id) {
  var usercon = user.find({UserID: id});
  return usercon;
}

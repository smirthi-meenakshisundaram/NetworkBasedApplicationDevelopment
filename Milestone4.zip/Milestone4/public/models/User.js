var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');

var userSchema = new mongoose.Schema({
    UserID: Number,
    password:String,
    firstName: String,
    lastName: String,
    emailAddress: String,
    address1Field: String,
    address2Field: String,
    city: String,
    state: String,
    zipcode: Number,
    country: String
},{collection:'users'});

var useData = mongoose.model('users', userSchema);
module.exports = useData;

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');


var userawardSchema = new mongoose.Schema({
  UserID:String,
  connectionName: String,
   connectiontopic: String,
   rsvp: String
});


var userawardDB = mongoose.model('userawards', userawardSchema);
module.exports = userawardDB;

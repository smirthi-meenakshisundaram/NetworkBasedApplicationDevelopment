// creating a class connection and using get and set to get the values
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');

var awardSchema = new mongoose.Schema({
  connectionID:String,
  connectionName:String,
  connectiontopic:String,
  details:String,
  releasedateTime:String,
  location:String,
  imageurl:String,
  UserID:Number,
});

var connectionDB = mongoose.model('awards', awardSchema);
module.exports = connectionDB;

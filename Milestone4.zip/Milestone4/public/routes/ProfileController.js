var express = require('express');
var router = express.Router();
var bodyparser = require('body-parser');
var UserProfileModel = require('../util/userDB');
var User = require('../models/User');
var UserConnections = require('../models/userConnection');
var urlencoded = bodyparser.urlencoded({ extended: false });
var obj = require('../util/connectionDB');
var job1=require('../models/connection')
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
mongoose.Promise = global.Promise;


var loggedIn = false;

router.get('/connections', function (req, res) {
    obj.getConnections().exec(function (err, data) {
        if (err) throw err
        obj.getCategory().exec(function (err, category) {
            if (err) throw err
            console.log("category is:" + category);
          //  res.render('connections', { data: data, category: category, isLoggedIn: (req.session.UserID) ? true : false });
            res.render('connections', { data: data, category: category, isLoggedIn: loggedIn });
        })
    })
});


router.get('/login', function (req, res) {


if (!loggedIn) {
 //res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined });
 res.render('login', { isLoggedIn: loggedIn });


        //console.log("in signin " + req.session.theUser);
        //loggedIn = true;
    }
});

router.post('/login', function (req, res) {
    //console.log("logged or not " + loggedIn)
    //req.session.theUser = UserProfileModel.getUserConnections();
     loggedIn = true;
     //req.session.UserID = 801129947;
   var user = UserProfileModel.getUser(801129947).exec(function (err, res1) {
       if (err) {

           throw err;
       }
   console.log(user);
  req.session.UserID= res1[0].UserID;
     res.redirect('/savedconnections')

     //var usersession = req.session.theUser;
     //var parsedpro = new UserProfile(usersession);
     //console.log("parsedprofile  " + parsedpro);
    // console.log(parsedpro.getConnections);
  //res.render('savedconnections', { data: parsedpro.getConnections(), isLoggedIn: loggedIn });
})
});

router.get('/savedconnections', function (req, res) {

    if (!loggedIn) {
        UserProfileModel.getUserConnections().exec(function (err, result) {
            if (err) throw err;
            res.render('savedconnections', { data: result, isLoggedIn: loggedIn });
        })
    }
    else {
        console.log(" reached else here" + loggedIn);
        UserProfileModel.getUsers().exec(function (err, res1) {
            if (err) {
                console.log('err');
                throw err;
            }
            console.log("res1");
            console.log(res1);

            req.session.UserID = res1[0].UserID;
            console.log("req.session.UserID")
        })
        UserProfileModel.getUserConnections().exec(function (err, result) {
            if (err) throw err;
            console.log("we r here in");
            console.log(result);

            console.log(loggedIn);
            res.render('savedconnections', { data: result, isLoggedIn: loggedIn });
        })
    }
});

router.get('/newConnection', function (req, res) {
    if (loggedIn) {

        res.render('newConnection', { isLoggedIn: loggedIn });
    }
    else {
        res.render('login', { isLoggedIn: loggedIn });
    }

});

router.get('/logout', function (req, res) {
    loggedIn = false;
    req.session.destroy();

    res.render('index', { isLoggedIn: loggedIn });
});

router.get('/', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn });
});

router.get('/index', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn });
});





/*router.get('/myjobs', function (req, res) {
    res.render('myjobs');
})*/
router.get('/connection/:connectionName', function (req, res) {
    var job = obj.getConnectionByName(req.params.connectionName).exec(function (err, data1) {
        if (err) throw err
        console.log(data1);
        res.render('connection', { data: data1, isLoggedIn: loggedIn });
    })

})



router.get('/contact', function (req, res) {
    res.render('contact', { isLoggedIn: loggedIn });


});

router.get('/about', function (req, res) {
    res.render('about', { isLoggedIn: loggedIn });


});

router.post('/newConnection', urlencoded, function (req, res) {
    var newConnection = [{ UserID: req.session.UserID, connectionName: req.body.connectionName,  connectionID: req.body.connectionID, details: req.body.details, releasedateTime: req.body.releasedateTime, imageurl: req.body.imageurl,  connectiontopic: req.body.connectiontopic, location: req.body.location}];
    var save = [{UserID: req.session.UserID,connectionName: req.body.connectionName,connectiontopic: req.body.connectiontopic,rsvp:"yes"}];
    job1.find({ connectionName: req.body.connectionName, connectiontopic: req.body.connectiontopic }).exec(function (err, docs) {
        if (err) throw err;

        if (docs.length == 0) {
           job1.insertMany(newConnection, function (err, docs) {
                if (err) throw err;
            })


        }

    })
    UserConnections.find({ connectionName: req.body.connectionName, connectiontopic: req.body.connectiontopic }).exec(function (err, docs) {
        if (err) throw err;

        if (docs.length == 0) {
           UserConnections.insertMany(save, function (err, docs) {
                if (err) throw err;
            })


        }

    })

    res.redirect('/savedconnections');
    //res.redirect('/savedconnections')
});


router.post('/savedconnections', urlencoded, function (req, res) {
    var task = req.body.action;

    switch (task) {
        case "delete":
            if (loggedIn) {
                var act = req.body.actionOp;
                var delitem = req.body.connectionName;
                UserConnections.deleteOne({ connectionName: delitem }).exec(function (err, result) {
                    if (err) throw err;


               })

                res.redirect('/savedconnections')
                //res.render('login', {isLoggedIn: loggedIn });
            }
            else {
              //  res.redirect('/savedconnections')
              res.render('login', {isLoggedIn: loggedIn });
            }

            break;
        case "update":
            console.log(req.session.theUser);
            if (loggedIn) {

                UserConnections.findOneAndUpdate({
                    //UserID: 801129947,
                    UserID: req.session.UserID,
                    connectionName: req.body.connectionName,
                },
                    {
                        connectionName: req.body.connectionName,
                        rsvp: req.body.rsvp,
                         connectiontopic: req.body.connectiontopic,
                    },
                    { upsert: true, returnNewDocument: true }).exec(function (err, docs) {
                        if (err) throw err;
                        console.log(docs);
                    });
                res.redirect('/savedconnections');
            }
            else {

              res.render('login', {isLoggedIn: loggedIn });
            }
            break;

    }
});

router.get("*", function (req, res) {
    res.render('index', { isLoggedIn: loggedIn });
});

module.exports = router;

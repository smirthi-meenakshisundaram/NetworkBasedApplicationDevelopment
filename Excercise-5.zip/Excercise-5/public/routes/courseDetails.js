var express = require('express');
var app = express();
var bodyParser=require('body-parser');
var router = express.Router();
var session = require('express-session');
var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.use(session({secret:'About Course'}));

var theCourse;
var x=0;

var myLogger = function (req, res, next) {
  x=x+1;
  console.log(x+" times the pages has been visited");
  next();

}

 router.post('/',urlencodedParser,myLogger,function(req,res,next){
   if(req.body.courseID=='' && req.body.title =='' &&  req.body.term=='' && req.body.instructor==''){
     res.render('index',{x:x});
   }
   else{
    var courseModel = require('./../models/Course');
  //  var post_id = req.body.Id;
//  var post_Title = req.body.Title;
//  var post_Term = req.body.Term;
//  var post_Instructor = req.body.Instructor;

    // courseModel = courseModel.course(req.body.courseID,
    //                                  req.body.title,
    //                                  req.body.term,
    //                                  req.body.instructor);
    courseModel = courseModel.course(req.body.courseID,
                                               req.body.title,
                                               req.body.term,
                                               req.body.instructor);


req.session.theCourse=courseModel;

if(req.session.theCourse.courseID==''){
  res.redirect('/index');

} else{
  
    res.redirect('/courseDetails');
  }
}
});
  router.get('/', function (req, res) {

 if(req.session.theCourse){
res.render('details', {course:req.session.theCourse});
               res.end();
         }
         else{
          console.log("in no info");
          res.render('index',{x:x});
          res.end();
         }

     });



module.exports = router;
module.exports.x = function(value) {
  value=x;
return value;
};


var http = require('http');
var fs = require('fs');


//create a server object:
var server = http.createServer(function (req, res) {

  fs.readFile("viewTextInBrowser.txt", "utf8", function(err,data){
      if(err) throw err;
      res.write(data);
      res.end();
  });

});
server.listen(8080); //the server object listens on port 8080

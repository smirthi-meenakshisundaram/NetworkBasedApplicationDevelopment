var express = require('express');
var router = express.Router();
var courseDetails= require('./coursedetails.js')
var mongoose = require('mongoose');
var Course = require('../model/Coursemodel');


mongoose.connect('mongodb://localhost/Courses', { useNewUrlParser: true });
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
    // we're connected!`enter code here

    var c1 = new Course({
        courseID: 1211,
        title: 'C Programming',
        term: 'Fall 2019',
        instructor: 'Seema'
    });
    var c2 = new Course({
        courseID: 1211,
        title: 'Java Programming',
        term: 'Fall 2020',
        instructor: 'Rob'
    });
    var c3 = new Course({
        courseID: 6162,
        title: 'Python Programming',
        term: 'Spring 2019',
        instructor: 'Pooja'
    });
    var c4 = new Course({
        courseID: 6162,
        title: 'My Sql',
        term: 'Spring 2020',
        instructor: 'Bob'
    });

    c1.save(function(err, c1) {
        if (err) return console.error(err);
        console.log("course 1 saved");
    });
    c2.save(function(err, c2) {
        if (err) return console.error(err);
        console.log("course 2 saved");
    });
    c3.save(function(err, c3) {
        if (err) return console.error(err);
        console.log("course 3 saved");
    });
    c4.save(function(err, c4) {
        if (err) return console.error(err);
        console.log("course 4 saved");
    });

});






router.get('/', function (req, res) {
  res.render('index',{x:courseDetails.x()});
});

module.exports = router;

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var router = express.Router();
var session = require('express-session');
var urlencodedParser = bodyParser.urlencoded({ extended: false });

var courselist =require('../model/Coursemodel');
var mongoose = require('mongoose');


mongoose.connect('mongodb://localhost/Courses', {useNewUrlParser: true});
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));



app.use(session({ secret: 'my secret' }));

var theCourse;
var x = 0;

var loggerFun = function(req,res,next){
    x+=1;
    console.log(x + "Times form submitted");
    next();

}

router.post('/', urlencodedParser,loggerFun, function(req, res) {
    var courseModel = require('../model/course.js');
    var post_id = req.body.id;
    var post_Title = req.body.title;
    var post_Term = req.body.term;
    var post_Instructor = req.body.instructors;
    post_id = parseInt(post_id);
    courseModel = courseModel.coursedetails(post_id,
        post_Title,
        post_Term,
        post_Instructor);
    req.session.theCourse = courseModel;



    courselist.find({ courseID: post_id ,term: post_Term,instructor: post_Instructor}, function(err, searchresult) {
        if(searchresult.length > 0){
            var myquery = { courseID: post_id,term:post_Term,instructor:post_Instructor};
            var newvalues = { courseID: post_id,title: post_Title,term:post_Term,instructor:post_Instructor};
            courselist.updateOne(myquery, newvalues, function(err, res) {
                if (err) console.log(err);
                console.log("Database updated");
              });
            res.redirect('/');
        }
        else{
            var newcourse = new courselist({
                courseID: post_id,
                title: post_Title,
                term: post_Term,
                instructor: post_Instructor
            });
            newcourse.save(function(err, newcourse) {
                if (err) return console.error(err);
                console.log("adding new course");
            });
            res.redirect('/allcourses');

        }


    });


});

router.get('/', function(req, res) {
    if (req.session.theCourse) {
        res.render('details', { course: req.session.theCourse });
        res.end();
    } else {

        res.render('index',{x:x});
        res.send();
    }
});


module.exports = router;
module.exports.x = function(value) {
    test = x;
    return test;
};

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var courseSchema = new Schema({
    courseID: {
        type: Number,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    term: {
        type: String
    },
    instructor: {
        type: String
    }
});

module.exports = mongoose.model('Course', courseSchema);
var course = function(id, title, term, instructor){
  var courseModel={
    CourseId: id,
    Title: title,
    Term: term,
    Instructor: instructor};
    return courseModel;
}

module.exports.coursedetails=course;

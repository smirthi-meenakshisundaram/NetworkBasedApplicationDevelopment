var User = require("../models/User");
var UserConnection = require("../models/UserConnection");
var Connection = require('../util/ConnectionDB');
var UserProfile = require("../models/UserProfile");

var udata = [
    {
        UserID: 'smeenak1',
        firstName: 'Smirthi',
        lastName: 'Meenakshisundaram',
        emailAddress: 'smeenak1@uncc.edu',
        address1Field: '9547 H',
        address2Field: 'UT',
        city: 'charlotte',
        state: 'north carolina',
        postCode: '28262',
        country: 'USA'
    },

    {
        UserID: 'sheena9',
        firstName: 'Sheena',
        lastName: 'Dubey',
        emailAddress: 'sheena9@uncc.edu',
        address1Field: '9509 F',
        address2Field: 'UT',
        city: 'charlotte',
        state: 'north carolina',
        postCode: '28262',
        country: 'USA'
    }
];


module.exports.getUsers = function () {//getUsers function used to retrive users

    let users = [];
    for (let i = 0; i < udata.length; i++) {
        let user = new User(
            udata[i].UserID,
            udata[i].firstName,
            udata[i].lastName,
            udata[i].emailAddress,
            udata[i].address1Field,
            udata[i].address2Field,
            udata[i].city,
            udata[i].state,
            udata[i].zipcode,
            udata[i].country);
        users.push(user);
        //adding users into list
        //console.log("all users retrived successfully")
    }
    return users; // return first user for now as there is no user signup for our application so for now always return first user by users[0] if getUsers is used


};

var UserConnection1 = new UserConnection(
    Connection.getConnection('NOM03').connectionName,   
    rsvp = "No",
    Connection.getConnection('NOM03').connectiontopic,
)
var UserConnection2 = new UserConnection(
    Connection.getConnection('NOM02').connectionName,
    rsvp="No",
    Connection.getConnection('NOM02').connectiontopic,
)

var userConnections = [];
console.log("user connections");
console.log(UserConnection1);

module.exports.UserProfile1 = new UserProfile(udata[0].UserID, userConnections);//this user profile is used for displying profileview after using signin in button

module.exports.getUsize = function () {

    return udata.length;
}




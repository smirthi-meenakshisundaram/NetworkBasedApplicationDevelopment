var UserConnection = require('../models/UserConnection')

class UserProfile {

    constructor(UserID, UserConnections) {
        this._UserID = UserID;
        this._UserConnections = UserConnections;
    };

    get UserID() {
        return this._UserID;
    }
    set UserID(value) {
        this._UserID = value;
    }

    get UserConnections() {
        return this._UserConnections;
    }
    set UserConnections(value) {
        this._UserConnections = value;
    }

    

    getConnections() {
        return this._UserConnections;
    }
 
    addConnection(userConnection) {
        console.log("in add connection");
        var Connections = this._UserConnections;
        console.log("beffore adding");
        console.log(Connections);
        console.log("userConnection is");
        console.log(userConnection);
        var count = 0, n = Connections.length;
        console.log("n value is " + n);
        if(n>0){//checking for no saved Connections
            for (let i = 0; i < n; i++) {
                console.log(Connections[i]);
           console.log(Connections[i].connectionName);
           console.log(userConnection.connectionName);
           if (Connections[i].connectionName != userConnection.connectionName){
           count++;
           console.log(count);
         if(count==n){
             Connections.push(userConnection);
             console.log("after push");
             console.log(Connections);
         }
       }

   }
}
        else {
            console.log("in add connection else ");
   Connections.push(userConnection);
}
  this._UserConnections=Connections;

    }

  /*  addConnection(userConnection) {
        var Connections = this._UserConnections;
        var count = 0;
        var n = Connections.length;
        if (n > 0) {
            for (let i = 0; i < n; i++) {
                if (Connections[i].ConnectionName != ConnectionName) {
                    count++;
                    if (count == n) {
                        Connections.push(userConnection);
                    }
                }
            }
        }
        else {
            connections.push(userConnection);
        }
        this._UserConnections = Connections;
    }*/

    updateConnection(ConnectionName, rsvp, connectiontopic) {
        console.log("in update connection");
        var Connections = this._UserConnections;
        console.log("connections are" + Connections);
        for (let i = 0; i < Connections.length; i++) {
            if (Connections[i].connectionName == ConnectionName) {
                console.log("name is getting here correct in update");
                if (Connections[i].rsvp != rsvp) {
                    var userConnection = new UserConnection(Connections[i].connectionName, rsvp, connectiontopic);
                    Connections.splice(i, 1, userConnection);
                }
            }
        }
        this._UserConnections = Connections;
    }

    removeConnection(userConnection) {
        console.log("comming to remove" + userConnection);
        var Connections = this._UserConnections;
        console.log(Connections);
        for (let i = 0; i < Connections.length; i++) {
            if (Connections[i].connectionName == userConnection.connectionName ) {
                Connections.splice(i, 1);
            }
        }
        this._UserConnections = Connections;
    }

    emptyProfile() {
        this.UserConnections=null;
    }
    convert(obj) {
        Object.assign(this, obj);
    }
}

module.exports = UserProfile;
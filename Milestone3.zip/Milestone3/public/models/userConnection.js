class Userconnection {

    constructor(connectionName, rsvp, connectiontopic) {
        this._connectionName = connectionName;
        this._rsvp = rsvp;
        this._connectiontopic = connectiontopic;
    }
    
    get connectionName() {
        return this._connectionName;
    }

    set connectionName(value) {
        this._connectionName = value;
    }

    get connectiontopic() {
        return this._connectiontopic;
    }
    set connectiontopic(value) {
        this._connectiontopic = value;
    }
    get rsvp() {
        return this._rsvp;
    }

    set rsvp(value) {
        this._rsvp = value;
    }

    
    convert(obj) {
        Object.assign(this, obj);
    }

}
module.exports = Userconnection;

var express = require('express');
var app = express();
var path = require('path')
var session = require('express-session');
var utility = require('../util/connectionDB');
var usercontroller = require('../controller/UserController');
var index = require('../routes/index');
app.use(express.static("../assets"));

app.set("views", "../views");
app.set('view engine', 'ejs');
app.use(session({ secret: 'smrithi', resave: false, saveUninitialized: true }));
app.use('/', usercontroller);



app.listen(9090, function () {
    console.log('app started')
    console.log('listening on port 9090')
});

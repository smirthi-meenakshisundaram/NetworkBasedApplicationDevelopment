var express = require('express');
var router = express.Router();
var bodyparser = require('body-parser');
var UserProfileModel = require('../util/userdb');
var User = require('../models/User');
var usercon = require('../models/userConnection');
var UserProfile = require('../models/UserProfile');
var urlencoded = bodyparser.urlencoded({ extended: false });
var utility = require('../util/connectionDB');


var loggedIn = false;





router.get('/login', function (req, res) {

    // console.log("login-->savedConnections");
    if (!loggedIn) {
        //req.session.theUser = UserProfileModel.UserProfile1;
        //console.log("in login " + req.session.theUser);
        //loggedIn = true;
    }

    res.render('login', { isLoggedIn: loggedIn });
    
});
router.get('/', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn })
})

router.get('/about', function (req, res) {
    res.render('about', { isLoggedIn: loggedIn })
})

router.get('/contact', function (req, res) {
    res.render('contact', { isLoggedIn: loggedIn })
})

router.get('/newConnection', function (req, res) {
    res.render('newConnection', { isLoggedIn: loggedIn })
});

router.get('savedConnectionlgin', function (req, res) {
    loggedIn = true;
    req.session.theUser = UserProfileModel.UserProfile1;
    var usersession = req.session.theUser;
    var parsedpro = parseToUserProfile(usersession);
    res.render('savedConnections', { data: parsedpro.getConnections(), isLoggedIn: loggedIn });
})
router.post('/login', function (req, res) {
    console.log("logged or not " + loggedIn)
    req.session.theUser = UserProfileModel.UserProfile1;
     loggedIn = true;
     var usersession = req.session.theUser;
     var parsedpro = parseToUserProfile(usersession);
     console.log("parsedprofile  " + parsedpro);
     console.log(parsedpro.getConnections);
    res.render('savedConnections', { data: parsedpro.getConnections(), isLoggedIn: loggedIn });
})

router.get('/savedConnections', function (req, res) {
    //console.log("in first savedConnections");
    if (!loggedIn) {
        
        res.render('login', { isLoggedIn: loggedIn });
    }

    else if (loggedIn) {
        // console.log("here we are");
        var usersession = req.session.theUser;
        var parsedpro = parseToUserProfile(usersession);
        console.log("parsedprofile  " + parsedpro);
        console.log(parsedpro.getConnections);
        res.render('savedConnections', { data: parsedpro.getConnections(), isLoggedIn: loggedIn });
    }
    
   
});




router.get('/logout', function (req, res) {
    loggedIn = false;
    req.session.destroy();
    //console.log('desttryed here');
    res.render('index', { isLoggedIn: loggedIn });
});

router.get('/index', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn });
});




router.get('/connections', function (req, res) {
    var filmCat = [];
    var film = utility.getConnections();
    for (var i = 0; i < film.length; i++) {
        filmCat.push(film[i].connectiontopic)
    }
    var Category = filmCat.filter((cat, ind, item) => item.indexOf(cat) === ind);
    res.render('connections', { querystring: film, unique: Category, isLoggedIn: loggedIn });
});


router.get('/connection/:ID', function (req, res) {
    //var ID = req.query.ID
        var detail = utility.getConnection(req.params.ID);
        console.log(detail);
        var response = [];
        response.push(detail);

        console.log(response.length);
        res.render('connection', { querystring: response, isLoggedIn: loggedIn })
    
})

router.get('/connection_detail/:Name', function (req, res) {
    console.log("Name is " + req.params.Name);
    var detail = utility.getConnectionbyName(req.params.Name);
    console.log(detail);
    var response = [];
    response.push(detail);

    res.render('connection', { querystring: response, isLoggedIn: loggedIn })
})


router.get('/contact', function (req, res) {
    res.render('contact', { isLoggedIn: loggedIn });


});

router.get('/about', function (req, res) {
    res.render('about', { isLoggedIn: loggedIn });


});


router.post('/savedConnections', urlencoded, function (req, res) {
    var task = req.body.action;


    switch (task) {
        case "delete":
            if (req.session.theUser && loggedIn) {
                var usersession = req.session.theUser;
                var parsedpro = parseToUserProfile(usersession);
                mycon = new usercon(req.body.connectionName, req.body.rsvp, req.body.connectiontopic);
                console.log(mycon);
                parsedpro.removeConnection(mycon);
                req.session.theUser = parsedpro;
                res.render('savedConnections', { data: req.session.theUser.getConnections(), isLoggedIn: loggedIn });
            }
            else {
                
                res.render('login', {isLoggedIn: loggedIn });
            }
            break;
        case "update":
            console.log("in update");
 
            console.log(req.session.theUser);
            if (req.session.theUser && loggedIn) {
                var usersession = req.session.theUser;
                var parsedpro = parseToUserProfile(usersession);
                let mycon = new usercon(req.body.connectionName, req.body.rsvp, req.body.connectiontopic);
                console.log("updated my con");
                console.log(mycon);
                parsedpro.addConnection(mycon);
                parsedpro.updateConnection(req.body.connectionName, req.body.rsvp, req.body.connectiontopic);
                req.session.theUser = parsedpro;
                res.render('savedConnections', { data: req.session.theUser.getConnections(), isLoggedIn: loggedIn });
            }
            else {
               
                res.render('login', {isLoggedIn: loggedIn });
            }
            break;

    }
});

router.get("*", function (req, res) {
    res.render('index', { isLoggedIn: loggedIn });
});

var parseToUserProfile = function (utility) {
    console.log("utility is");
    console.log(utility);

    var userID = utility._UserID;
    var userConnections = utility._UserConnections;
    var uconnections = [];
    for (var i = 0; i < userConnections.length; i++) {
        var temp = new usercon(userConnections[i]._connectionName, userConnections[i]._rsvp, userConnections[i]._connectiontopic);
        uconnections.push(temp);
    }
    var parsedpro = new UserProfile(userID, uconnections);
    return parsedpro;
};


module.exports = router;
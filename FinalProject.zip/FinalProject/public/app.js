var express = require("express");
var app = express();
var session = require('express-session');
var profileController = require('./routes/ProfileController');
var path = require('path');

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));
app.use("/partials", express.static("partials"));
app.use(session({ secret: 'smirthi', resave: false, saveUninitialized: true }));
app.use('/', profileController);
app.use('*', profileController);



app.listen(9090);
console.log('app started')
console.log('listening on port 9090')

  module.exports = app;

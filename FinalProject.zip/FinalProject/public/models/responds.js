var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');


var respondsSchema = new mongoose.Schema({
  UserID:String,
  username:String,
  connectionName: String,
  connectiontopic: String,
   rsvp: String
});


var respondDB = mongoose.model('responds', respondsSchema);
module.exports = respondDB;

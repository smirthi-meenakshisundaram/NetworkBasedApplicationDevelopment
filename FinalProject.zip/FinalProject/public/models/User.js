var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
const passportMongoose = require('passport-local-mongoose');

var userSchema = new mongoose.Schema({
    UserID: Number,
    password:String,
    firstName: String,
    lastName: String,
    username: String,
    address1Field: String,
    address2Field: String,
    city: String,
    state: String,
    zipcode: Number,
    country: String
},{collection:'users'});

/*var useData = mongoose.model('users', userSchema);
module.exports = useData;*/

userSchema.plugin(passportMongoose);
module.exports.userDB = mongoose.model('users', userSchema);

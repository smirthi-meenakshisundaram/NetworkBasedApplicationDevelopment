var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
mongoose.Promise = global.Promise;
var user = require("../models/User");
var UserConnection = require("../models/userConnection");
var Responds = require("../models/responds");





module.exports.getUsers = function () {
    var usr = user.userDB.find();
    return usr; // gets the details of all the users
}

module.exports.getUserConnections = function () {
    var userconnections = UserConnection.find();
    return userconnections;
}



module.exports.getUser = function (id) {
  var usercon = user.userDB.find({UserID: id});
  return usercon;
}

module.exports.getLoginDetails = function (email) {
    var loginDetails = user.userDB.find({ username: email});
    console.log('loginDetails');
    return loginDetails
}

module.exports.getUserConnectionsWithCode = function (ucode) {
    var nameWcode = UserConnection.find({ UserID: ucode })
    return nameWcode;
}

module.exports.getUserInvitesWithCode = function (ucode) {
    var invite = Responds.find({ UserID: ucode })
    return invite;
}

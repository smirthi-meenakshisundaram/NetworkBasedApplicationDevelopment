var express = require('express');
var router = express.Router();
var bodyparser = require('body-parser');
var UserProfileModel = require('../util/userDB');
var UserProfile = require('../util/userProfileDB.js')
var User = require('../models/User');
var UserConnections = require('../models/userConnection');
var Responds = require('../models/responds');
const { check, validationResult } = require('express-validator');
var bcrypt = require('bcryptjs');
var urlencoded = bodyparser.urlencoded({ extended: false });
var obj = require('../util/connectionDB');
var job1=require('../models/connection')
const passport = require('passport');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/m4data');
mongoose.Promise = global.Promise;


var loggedIn = false;

router.get('/connections', function (req, res) {
    obj.getConnections().exec(function (err, data) {
        if (err) throw err
        obj.getCategory().exec(function (err, category) {
            if (err) throw err
            console.log("category is:" + category);

            res.render('connections', { data: data, category: category, isLoggedIn: loggedIn, user: req.session.theUser });
        })
    })
});
router.get('/invite', function (req, res) {

  obj.getConnections().exec(function (err, data) {
      if (err) throw err
      UserProfileModel.getUsers().exec(function (err,use) {
          if (err) throw err


            res.render('invite', { data: data, use: use, isLoggedIn: loggedIn, user: req.session.theUser });
        })
    })
});

router.post('/invite', urlencoded, [check('connectionName').isLength({min:3}).withMessage('connectionName must be atleast of length of 3'),
    check('username').isEmail().withMessage('username must be a valid mail')], function (req, res) {
        const errors = validationResult(req);
        console.log(errors);
        console.log(errors.mapped());
        if (!errors.isEmpty()) {
            res.render('invite', { isLoggedIn: loggedIn, error: errors.array(), user: req.session.theUser });
}
  else {

var username = req.body.username;
//var connectionName= req.body.connectionName;
obj.getConnectionByName(req.body.connectionName).exec(function (err, dest) {
  if(err) throw err;
  else {
    connectiontopic = (dest[0].connectiontopic)

  UserProfileModel.getLoginDetails(username).exec(function (err, docs) {
    if(err) throw err;
    else {
  UserID = (docs[0].UserID);
  var newConnection = [{ username:req.body.username, connectionName: req.body.connectionName, UserID:UserID, connectiontopic:connectiontopic}];
  Responds.find({ connectionName: req.body.connectionName,username:req.body.username}).exec(function (err, docs) {
      if (err) throw err;
 if (docs.length == 0) {
       Responds.insertMany(newConnection, function (err, docs) {
              if (err) throw err;
         })
     }
   })
  }
})
}
})
  res.redirect('/invite_sent');
}
});

router.get('/respond', function (req, res) {

    if (!loggedIn) {
  res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined, user: req.session.theUser });
        }
    else {
        console.log(" reached else here" + loggedIn);
        UserProfileModel.getUsers().exec(function (err, res1) {
            if (err) {
                console.log('err');
                throw err;
            }
            console.log("req.session.UserID")
            console.log(req.session.UserID);
        })
        UserProfileModel.getUserInvitesWithCode(req.session.UserID).exec(function (err, result) {//gets users based on the UserID
            if (err) throw err;
          //  console.log("we r here in");
          //  console.log(result);

            console.log(loggedIn);
            res.render('respond', { data: result, isLoggedIn: loggedIn, user: req.session.theUser });
        })


    }
});



router.get('/login', function (req, res) {


if (!loggedIn) {
//res.render('login', { isLoggedIn: loggedIn });
res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined, user: req.session.theUser });
return;
      }
    res.redirect('/savedconnections');
});

router.post('/login', urlencoded, [
    check('username').isEmail().withMessage('Enter a valid email'),
    check('password').isLength({ min: 5, max: 54 })
        .withMessage('Password length must be between 5 and 54')], function (req, res) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            console.log(errors);
            res.render('login', { isLoggedIn: loggedIn, error: errors.array(), err: undefined, user: req.session.theUser });
        }
        else {
            var username = req.body.username;
            var password = req.body.password;
            var saltrounds = 10;
            UserProfileModel.getLoginDetails(username).exec(function (err, docs) {
                //console.log(docs)
                if (docs.length == 0) {
                    res.render('login', { isLoggedIn: loggedIn, err: "Invalid Username/Password", error: undefined, user: req.session.theUser });
                }
                else {
                    console.log('here it is');
                    //console.log(docs[0]);
                    var hash = bcrypt.hashSync(docs[0].password, saltrounds);//generating hash for password
                    var phash = bcrypt.compareSync(password, hash);//comapring password against hash
                    if (phash == true) {
              UserID = (docs[0].UserID);
            req.session.theUser = docs[0];
            req.session.UserID = UserID;
          console.log(req.session.UserID);
          loggedIn = true;
  res.redirect('/savedconnections')
                  //console.log(hash);
                    }
                    else {
                        res.render('login', { isLoggedIn: loggedIn, err: 'invalid password', error: undefined, user: req.session.theUser });
                    }
                }
            })
        }
});



router.get('/savedconnections', function (req, res) {

    if (!loggedIn) {
  res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined, user: req.session.theUser });
        }
    else {
        console.log(" reached else here" + loggedIn);
        UserProfileModel.getUsers().exec(function (err, res1) {
            if (err) {
                console.log('err');
                throw err;
            }
            console.log("req.session.UserID")
            console.log(req.session.UserID);
        })
        UserProfileModel.getUserConnectionsWithCode(req.session.UserID).exec(function (err, result) {//gets users based on the UserID
            if (err) throw err;
            console.log("we r here in");
            console.log(result);

            console.log(loggedIn);
            res.render('savedconnections', { data: result, isLoggedIn: loggedIn, user: req.session.theUser });
        })


    }
});

router.get('/newConnection', function (req, res) {
    if (loggedIn) {
      //loggedIn = true;
    res.render('newConnection', { isLoggedIn: loggedIn, error: undefined, user: req.session.theUser });
    }
    else {
        res.render('login', { isLoggedIn: loggedIn });
    }

});

router.get('/logout', function (req, res) {
    loggedIn = false;
    req.session.destroy();

    res.render('index', { isLoggedIn: loggedIn, user:'' });
});

router.get('/', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn, user:req.session.theUser });
});

router.get('/index', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn, user:req.session.theUser });
});






router.get('/connection/:connectionName', function (req, res) {
    var job = obj.getConnectionByName(req.params.connectionName).exec(function (err, data1) {
        if (err) throw err
        console.log(data1);
        req.session.connectionName = data1[0].connectionName;
        res.render('connection', { data: data1, isLoggedIn: loggedIn, UserID: req.session.UserID, user: req.session.theUser});
    })

})



router.get('/contact', function (req, res) {
    res.render('contact', { isLoggedIn: loggedIn, user:req.session.theUser });


});
router.get('/invite_sent', function (req, res) {
    res.render('invite_sent', { isLoggedIn: loggedIn, user:req.session.theUser });


});

router.get('/about', function (req, res) {
    res.render('about', { isLoggedIn: loggedIn, user:req.session.theUser });


});

router.post('/newConnection', urlencoded, [check('connectionID').isAlphanumeric().withMessage('connectionID must be Alphanumeric'),
    check('connectionName').isLength({min:3}).withMessage('connectionName must be atleast of length of 3'),
    check('connectiontopic').isAlpha().withMessage('connectiontopic must be alphabets'),
      check('location').isAlpha().withMessage('location must be alphabets'),
        check('details').isLength({min:2}).withMessage('details must atleast have length 3'),
    check('releasedateTime').isISO8601().withMessage('releasedateTime must be a valid date')], function (req, res) {
        const errors = validationResult(req);
        console.log(errors);
        console.log(errors.mapped());
        if (!errors.isEmpty()) {
            res.render('newConnection', { isLoggedIn: loggedIn, error: errors.array(), user: req.session.theUser });
}
  else {
            console.log("session user :"+req.session.UserID);
    var newConnection = [{ UserID: req.session.UserID, connectionName: req.body.connectionName,  connectionID: req.body.connectionID, details: req.body.details, releasedateTime: req.body.releasedateTime, imageurl: req.body.imageurl,  connectiontopic: req.body.connectiontopic, location: req.body.location}];
    var save = [{UserID: req.session.UserID,connectionName: req.body.connectionName,connectiontopic: req.body.connectiontopic,rsvp:"yes"}];
    job1.find({ connectionName: req.body.connectionName, connectiontopic: req.body.connectiontopic }).exec(function (err, docs) {
        if (err) throw err;

        if (docs.length == 0) {
           job1.insertMany(newConnection, function (err, docs) {
                if (err) throw err;
            })


        }

    })
    UserConnections.find({ connectionName: req.body.connectionName, connectiontopic: req.body.connectiontopic }).exec(function (err, docs) {
        if (err) throw err;

        if (docs.length == 0) {
           UserConnections.insertMany(save, function (err, docs) {
                if (err) throw err;
            })


        }

    })
  }

    res.redirect('/savedconnections');
    //res.redirect('/savedconnections')
});


router.post('/savedconnections', urlencoded, function (req, res) {
    var task = req.body.action;

    switch (task) {
        case "delete":
            if (loggedIn) {
                //var act = req.body.actionOp;
                var delitem = req.body.connectionName;

                UserConnections.deleteOne({ connectionName: delitem }).exec(function (err, result) {
                    if (err) throw err;
})
console.log(delitem);
res.redirect('/savedconnections')
                //res.render('login', {isLoggedIn: loggedIn });
            }
            else {
              //  res.redirect('/savedconnections')
              res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined, user: req.session.theUser });
            }

            break;
        case "update":
            console.log(req.session.theUser);
            if (loggedIn) {

                UserConnections.findOneAndUpdate({
                    //UserID: 801129947,
                    UserID: req.session.UserID,
                    connectionName: req.body.connectionName,
                },
                    {
                        connectionName: req.body.connectionName,
                        rsvp: req.body.rsvp,
                         connectiontopic: req.body.connectiontopic,
                    },
                    { upsert: true, returnNewDocument: true }).exec(function (err, docs) {
                        if (err) throw err;
                        console.log(docs);
                    });
                res.redirect('/savedconnections');
            }
            else {

              res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined, user: req.session.theUser });
            }
            break;

    }
});

router.get('/register', function (req, res) {
    //res.render('register', { isLoggedIn: loggedIn, user: req.session.theUser });
        res.render('register', { isLoggedIn: loggedIn, user: req.session.theUser, error: undefined, err: undefined, user: req.session.theUser });
});
router.get('/edit_info', function (req, res) {
    if (loggedIn) res.render('edit_info', { isLoggedIn: loggedIn, error: undefined,connectionName:req.session.connectionName, user: req.session.theUser })
    else res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined,connectionName:req.session.connectionName, user: req.session.theUser });
})
router.post('/edit_info', urlencoded, [check('connectiontopic').isAlpha().withMessage('connectiontopic must be alphabets'),
      check('location').isAlpha().withMessage('location must be alphabets'),
        check('details').isLength({min:2}).withMessage('details must atleast have length 3'),
    check('releasedateTime').isISO8601().withMessage('releasedateTime must be a valid date')], function (req, res) {
        var task = req.body.action1;

    switch (task) {
        case "delete":
            if (loggedIn) {
                var delitem = req.body.connectionName;
                job1.deleteOne({ connectionName: delitem }).exec(function (err, result) {
                    if (err) throw err;
                })
                UserConnections.deleteMany({ connectionName: delitem }).exec(function (err, result) {
                    if (err) throw err;
                })
                res.redirect('/connections');
            }
            break;
        case "navigate":
            if (loggedIn) {
                console.log('req.session.connectionName :' + req.session.connectionName);
                res.redirect('/edit_info');
            }
            break;

       case "edit_info":
           res.redirect('/edit_info');
            const errors = validationResult(req);
            console.log(errors);
            console.log(errors.mapped());
            if (!errors.isEmpty()) {
                res.render('edit_info', { isLoggedIn: loggedIn, error: errors.array(), connectionName: req.session.connectionName, user: req.session.theUser });
            }
           else if (loggedIn) {

                job1.findOneAndUpdate({
                    UserID: req.session.UserID,
                    connectionName: req.session.connectionName,

                },
                    {
                        connectiontopic: req.body.connectiontopic,
                        details: req.body.details,
                        releasedateTime: req.body.releasedateTime,
                        location: req.body.location
                    },
                    { upsert: true, returnNewDocument: true }).exec(function (err, docs) {
                        if (err) throw err;
                        console.log(docs);
                    });
                res.redirect('/connections');
            }
            else {
                res.redirect('/connections')
            }
            break;
    }
  });

  router.post('/update', urlencoded, [check('connectiontopic').isAlpha().withMessage('connectiontopic must be alphabets'),
        check('location').isAlpha().withMessage('location must be alphabets'),
          check('details').isLength({min:2}).withMessage('details must atleast have length 3'),
      check('releasedateTime').isISO8601().withMessage('releasedateTime must be a valid date')], function (req, res) {
        const errors = validationResult(req);
        console.log(errors);
        console.log(errors.mapped());
        if (!errors.isEmpty()) {
            res.render('edit_info', { isLoggedIn: loggedIn, error: errors.array(), connectionName: req.session.connectionName, user: req.session.theUser });
        }
        else if (loggedIn) {

            job1.findOneAndUpdate({
                UserID: req.session.UserID,
                connectionName: req.session.connectionName,

            },
                {
                    connectiontopic: req.body.connectiontopic,
                    details: req.body.details,
                    releasedateTime: req.body.releasedateTime,
                    location: req.body.location
                },
                { upsert: true, returnNewDocument: true }).exec(function (err, docs) {
                    if (err) throw err;
                    console.log(docs);
                });
            res.redirect('/connections');
        }
        else {
            res.redirect('/connections')
        }
    });

router.post('/register', urlencoded, [check('UserID').isNumeric().withMessage('UserID must be numeric'),
    check('firstName').isAlpha().withMessage('firstName must be alphabetical'),
    check('lastName').isAlpha().withMessage('lastName must be alphabetical'),
    check('username').isEmail().withMessage('username must be email'),
    check('zipcode').isNumeric().withMessage('zipcode must be numeric'),
    check('password').isLength({ min: 5 }).withMessage('password must be length of 5')], function (req, res) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            console.log(errors);
            res.render('register', { isLoggedIn: loggedIn, error: errors.array(), err: undefined, user: req.session.theUser });
        }
        else {
            var newUser = new User.userDB({
                UserID: req.body.UserID,
                firstName: req.body.firstName,
                lastName: req.body.lastName,
                username: req.body.username,
                password: req.body.password,
                address1Field: req.body.address1Field,
                address2Field: req.body.address2Field,
                city: req.body.city,
                state: req.body.state,
                zipcode: req.body.zipcode,
                country: req.body.country
            });
            //console.log(newUser);
            User.userDB.register(newUser, req.body.password, function (err, user) {
                if (err) {
                    console.log(err)
                    return res.render("register", { isLoggedIn: loggedIn, user: req.session.theUser, error: errors.array(), err: undefined });
                }
                passport.authenticate("local")(req, res, function () {
                    res.redirect("/");
                });
            });
        }
})

router.post('/respond', urlencoded, function (req, res) {
console.log("UserID smirthi");
    var task = req.body.action2;
     switch (task) {

       case "update":

                UserConnections.findOneAndUpdate({
                    //UserID: 801129947,
                    UserID: req.session.UserID,
                    connectionName: req.body.connectionName,
                },
                    {
                        connectionName: req.body.connectionName,
                        rsvp: req.body.rsvp,
                         connectiontopic: req.body.connectiontopic,
                    },
                    { upsert: true, returnNewDocument: true }).exec(function (err, docs) {
                        if (err) throw err;
                        console.log(docs);
                    })
                    Responds.findOneAndUpdate({
                        //UserID: 801129947,
                        UserID: req.session.UserID,
                         connectionName: req.body.connectionName,
                    },
                        {
                            connectionName: req.body.connectionName,
                            rsvp: req.body.rsvp,
                             connectiontopic: req.body.connectiontopic,
                             username:req.body.username,
                        },
                        { upsert: true, returnNewDocument: true }).exec(function (err, ders) {
                            if (err) throw err;
                            console.log(ders);
                        })

                res.redirect('/savedconnections');

          break;
        }

});


router.get("*", function (req, res) {
    //res.render('index', { isLoggedIn: loggedIn });
    res.render('index', { isLoggedIn: loggedIn, err: "", error: undefined, user: req.session.theUser });
});

module.exports = router;

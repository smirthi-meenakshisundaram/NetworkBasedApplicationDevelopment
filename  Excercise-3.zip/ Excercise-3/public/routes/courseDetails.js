
var express = require('express');
var router = express.Router();


router.get('/', function (req, res) {
  console.log(Object.keys(req.query).length);
  if(Object.keys(req.query).length == 0){
    console.log("in no info");
      res.render('nocourse');

  }
  else{
    var courseModel = require('./../models/Course');
     courseModel = courseModel.course(req.query.courseID,
                                              req.query.title,
                                              req.query.term,
                                              req.query.instructor);
    res.render('details', {course:courseModel});
  }

});
module.exports = router;
